//
//  ListDocenteViewController.swift
//  jjj
//
//  Created by DISEÑO on 5/12/24.
//

import UIKit
import CoreData

class ListDocenteViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var listDocenteTableView: UITableView!
    
    var personData = [Person]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        showData()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        listDocenteTableView.reloadData()
    }
    

    func connectBD() -> NSManagedObjectContext {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        return delegate.persistentContainer.viewContext
    }
    
    
    func configureTableView(){
        listDocenteTableView.delegate = self
        listDocenteTableView.dataSource = self
        listDocenteTableView.rowHeight = 280
    }
    
    
    func showData(){
        let context = connectBD()
        let fetchRequest: NSFetchRequest<Person> = Person.fetchRequest()
        do{
            personData = try context.fetch(fetchRequest)
            print("Se mostraron los datos en la tabla")
        } catch let error as NSError {
            print("Error al mostrar: \(error.localizedDescription)")
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserTableTableViewCell", for: indexPath) as? UserTableTableViewCell
        let person = personData[indexPath.row]
        cell?.configurePerson(person: person, viewController: self)
        
        return cell ?? UITableViewCell()
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        let context = connectBD()
        let person = personData[indexPath.row]
        if editingStyle == .delete {
            context.delete(person)
            do{
                try context.save()
                print("Se elimino el registro")
            }
            catch let error as NSError{
                print("Error al eliminar el registro: \(error.localizedDescription)")
            }
        }
        showData()
        listDocenteTableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "updateView", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "updateView"{
            if let id = listDocenteTableView.indexPathForSelectedRow{
                let rowPerson = personData[id.row]
                let router = segue.destination as? EditDocenteViewController
                router?.personUpdate = rowPerson
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
