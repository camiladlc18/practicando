//
//  EditDocenteViewController.swift
//  jjj
//
//  Created by DISEÑO on 5/12/24.
//

import UIKit
import CoreData

class EditDocenteViewController: UIViewController {

    @IBOutlet weak var nameEditTextField: UITextField!
    
    
    @IBOutlet weak var emailEditTextField: UITextField!
    
    @IBOutlet weak var dniEditTextField: UITextField!
    
    @IBOutlet weak var salarioEditTextField: UITextField!
    
    @IBOutlet weak var horasEditTextField: UITextField!
    
    @IBOutlet weak var beneficioEditTextField: UITextField!
    
    var personUpdate: Person?
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        configureTextField()
        // Do any additional setup after loading the view.
    }
    
    func connectBD() -> NSManagedObjectContext {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        return delegate.persistentContainer.viewContext
    }
    
    func configureTextField() {
        nameEditTextField.text = personUpdate?.name
        emailEditTextField.text = personUpdate?.email
        dniEditTextField.text = personUpdate?.dni
        salarioEditTextField.text = "\(personUpdate?.salario ?? 0)"
        horasEditTextField.text = "\(personUpdate?.horas ?? 0)"
        beneficioEditTextField.text = "\(personUpdate?.beneficio ?? 0)"
    }
    
    func editPerson() {
        let context = connectBD()
        
        personUpdate?.setValue(nameEditTextField.text, forKey: "name")
        personUpdate?.setValue(emailEditTextField.text, forKey: "email")
        personUpdate?.setValue(dniEditTextField.text, forKey: "dni")
        
        if let salario = Double(salarioEditTextField.text ?? "") {
            personUpdate?.setValue(salario, forKey: "salario")
        }
        
        if let horas = Double(horasEditTextField.text ?? "") {
            personUpdate?.setValue(horas, forKey: "horas")
        }
        
        if let beneficio = Double(beneficioEditTextField.text ?? "") {
            personUpdate?.setValue(beneficio, forKey: "beneficio")
        }
        
        do {
            try context.save()
            navigationController?.popViewController(animated: true)
            print("Se actualizo al usuario Docente")
        } catch let error as NSError{
            print("Error saving the updated person: \(error.localizedDescription)")
        }
    }
    
    @IBAction func didTapEdit(_ sender: UIButton) {
        editPerson()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
