//
//  ViewController.swift
//  jjj
//
//  Created by DISEÑO on 5/12/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    
    @IBOutlet weak var nameTextField: UITextField!
    
    
    @IBOutlet weak var emailTextField: UITextField!
    
    
    @IBOutlet weak var dniTextField: UITextField!
    
    
    @IBOutlet weak var salarioTextField: UITextField!
    
    
    @IBOutlet weak var horasTextField: UITextField!
    
    
    @IBOutlet weak var beneficioTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    func  connectBD() -> NSManagedObjectContext {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        return delegate.persistentContainer.viewContext
    }
    
    
    func savePerson() {
        let context = connectBD()
        let entityPerson = NSEntityDescription.insertNewObject(forEntityName: "Person", into: context) as! Person
        entityPerson.name = nameTextField.text
        entityPerson.email = emailTextField.text
        entityPerson.dni = dniTextField.text
        entityPerson.salario = Double(salarioTextField.text ?? "") ?? 0.0
        entityPerson.horas = Double(horasTextField.text ?? "") ?? 0.0
        entityPerson.beneficio = Double(beneficioTextField.text ?? "") ?? 0.0
        
        do {
            try context.save()
            clearTextField()
            print("Se guardo a la persona")
            
        }catch let error as NSError{
            print("Error al guardar: \(error.localizedDescription)")
        }
        
    }
    
    
    func clearTextField()
    {
        nameTextField.text = ""
        emailTextField.text = ""
        dniTextField.text = ""
        salarioTextField.text = ""
        horasTextField.text = ""
        beneficioTextField.text = ""
        nameTextField.becomeFirstResponder()
    }
    
    @IBAction func didTapRegister(_ sender: UIButton) {
        savePerson()
    }
}

