//
//  UserTableTableViewCell.swift
//  jjj
//
//  Created by DISEÑO on 5/12/24.
//

import UIKit

class UserTableTableViewCell: UITableViewCell {

    var person: Person?
    var viewController: UIViewController?
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var emailLabel: UILabel!
    
    
    @IBOutlet weak var dniLabel: UILabel!
    
    @IBOutlet weak var horasLabel: UILabel!
    
    @IBOutlet weak var salarioLabel: UILabel!
    
 
    
    
    @IBOutlet weak var beneficioLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        backgroundColor = UIColor.clear
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    
    func configurePerson(person: Person, viewController: UIViewController){
        self.nameLabel.text = "Nombre: \(person.name ?? "") 🙌🏿"
        self.emailLabel.text = "Email: \(person.email ?? "") 🙌🏿"
        self.dniLabel.text = "DNI: \(person.dni ?? "") 🙌🏿"
        self.salarioLabel.text = "Salario: \(person.salario ) 🙌🏿"
        self.horasLabel.text = "Horas: \(person.horas) 🙌🏿"
        self.beneficioLabel.text = "Beneficio: \(person.beneficio) 🙌🏿"
        self.person = person
        self.viewController = viewController
    }

}
